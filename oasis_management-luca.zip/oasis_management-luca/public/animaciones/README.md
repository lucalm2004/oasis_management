# animatedModal.js
<p>animatedModal.js is a jQuery plugin to create a fullscreen modal with CSS3 transitions. You can use the transitions from animate.css or create your own transitions.</p>
<a href="https://joaopereirawd.github.io/animatedModal.js/">Documentation and demos</a>
